package com.tekartik.sqflite.utils;

public class SqlUtils {

}
